// import {  Routes, Route, Navigate } from "react-router-dom";
// import Login from "./pages/Login";

// const Dashboard = () => <h2>Dashboard Page</h2>;

// const PrivateRoute = ({ children }) => {
//   const isAuth = localStorage.getItem("isAuthenticated");
//   return isAuth ? children : <Navigate to="/" />;
// };

// function App() {
//   return (
//     // <BrowserRouter>
//       <Routes>
//         <Route path="/" element={<Login />} />
//         <Route
//           path="/dashboard"
//           element={
//             <PrivateRoute>
//               <Dashboard />
//             </PrivateRoute>
//           }
//         />
//       </Routes>
//     // </BrowserRouter>
//   );
// }

// export default App;

import {  Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";

const PrivateRoute = ({ children }) => {
  const isAuth = localStorage.getItem("isAuthenticated");
  return isAuth ? children : <Navigate to="/" />;
};

function App() {
  return (
    // <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />
      </Routes>
    // </BrowserRouter>
  );
}

export default App;

