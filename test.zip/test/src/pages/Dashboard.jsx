import React, { useState } from "react";
import {
  Typography,
  Button,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  Avatar,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Grid,
  Card,
  CardContent
} from "@mui/material";
import { Add, Edit, Delete, Print } from "@mui/icons-material";
import DashboardLayout from "../layouts/DashboardLayout";
import EmployeeForm from "./EmployeeForm";
import { Chip } from "@mui/material";


const Dashboard = () => {
  const [employees, setEmployees] = useState([]);
  const [openForm, setOpenForm] = useState(false);
  const [editData, setEditData] = useState(null);

  const [deleteOpen, setDeleteOpen] = useState(false);
  const [selectedEmp, setSelectedEmp] = useState(null);

  const [search, setSearch] = useState("");
  const [genderFilter, setGenderFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");

  // COUNTS
  const totalEmployees = employees.length;
  const activeEmployees = employees.filter(e => e.status === "Active").length;
  const inactiveEmployees = employees.filter(e => e.status === "Inactive").length;

  // SAVE
  const handleSave = (data) => {
    if (editData) {
      setEmployees(prev =>
        prev.map(emp =>
          emp.id === editData.id ? { ...emp, ...data } : emp
        )
      );
    } else {
      setEmployees([...employees, { ...data, id: Date.now() }]);
    }
    setOpenForm(false);
    setEditData(null);
  };

  // DELETE
  const handleDeleteConfirm = () => {
    setEmployees(employees.filter(e => e.id !== selectedEmp.id));
    setDeleteOpen(false);
    setSelectedEmp(null);
  };

  // ✅ PRINT + IMAGE DOWNLOAD
  const handlePrint = (emp) => {
    const win = window.open("", "", "width=700,height=700");

    win.document.write(`
      <html>
        <head>
          <title>Employee Details</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 20px;
            }
            .container {
              max-width: 600px;
              margin: auto;
            }
            img {
              width: 120px;
              height: 120px;
              border-radius: 50%;
              object-fit: cover;
              margin-bottom: 10px;
            }
            .field {
              margin: 6px 0;
            }
            .download {
              display: inline-block;
              margin-bottom: 15px;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h2>Employee Details</h2>

            ${emp.image ? `<img src="${emp.image}" />` : ""}

            ${
              emp.image
                ? `<a class="download" href="${emp.image}" download="employee_${emp.id}.jpg">
                    Download Image
                  </a>`
                : ""
            }

            <div class="field"><b>ID:</b> ${emp.id}</div>
            <div class="field"><b>Name:</b> ${emp.name}</div>
            <div class="field"><b>Gender:</b> ${emp.gender}</div>
            <div class="field"><b>DOB:</b> ${emp.dob}</div>
            <div class="field"><b>State:</b> ${emp.state}</div>
            <div class="field"><b>Status:</b> ${emp.status}</div>

            <br />
            <button onclick="window.print()">Print</button>
          </div>
        </body>
      </html>
    `);

    win.document.close();
  };

  // FILTER
  const filteredEmployees = employees.filter(emp => {
    const nameMatch = emp.name.toLowerCase().includes(search.toLowerCase());
    const genderMatch = genderFilter === "All" || emp.gender === genderFilter;
    const statusMatch = statusFilter === "All" || emp.status === statusFilter;
    return nameMatch && genderMatch && statusMatch;
  });

  return (
    <DashboardLayout>
      <Typography variant="h5" mb={2}>
        Employee Dashboard
      </Typography>

      {/* SUMMARY CARDS */}
      <Grid container spacing={2} mb={3}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography>Total Employees</Typography>
              <Typography variant="h4">{totalEmployees}</Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card sx={{ bgcolor: "#e8f5e9" }}>
            <CardContent>
              <Typography>Active Employees</Typography>
              <Typography variant="h4" color="success.main">
                {activeEmployees}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card sx={{ bgcolor: "#ffebee" }}>
            <CardContent>
              <Typography>Inactive Employees</Typography>
              <Typography variant="h4" color="error.main">
                {inactiveEmployees}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Button
        variant="contained"
        startIcon={<Add />}
        sx={{ mb: 2 }}
        onClick={() => setOpenForm(true)}
      >
        Add Employee
      </Button>

      {/* TABLE */}
      <Paper sx={{ p: 2 }}>
        <Grid container spacing={2} mb={2}>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              size="small"
              label="Search by Name"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </Grid>

          <Grid item xs={12} md={4}>
            <TextField
              select
              fullWidth
              size="small"
              label="Gender"
              value={genderFilter}
              onChange={(e) => setGenderFilter(e.target.value)}
            >
              <MenuItem value="All">All</MenuItem>
              <MenuItem value="Male">Male</MenuItem>
              <MenuItem value="Female">Female</MenuItem>
            </TextField>
          </Grid>

          <Grid item xs={12} md={4}>
            <TextField
              select
              fullWidth
              size="small"
              label="Status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <MenuItem value="All">All</MenuItem>
              <MenuItem value="Active">Active</MenuItem>
              <MenuItem value="Inactive">Inactive</MenuItem>
            </TextField>
          </Grid>
        </Grid>

        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Profile</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Gender</TableCell>
              <TableCell>DOB</TableCell>
              <TableCell>State</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {filteredEmployees.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  No Records Found
                </TableCell>
              </TableRow>
            )}

            {filteredEmployees.map(emp => (
              <TableRow key={emp.id}>
                <TableCell>{emp.id}</TableCell>
                <TableCell><Avatar src={emp.image} /></TableCell>
                <TableCell>{emp.name}</TableCell>
                <TableCell>{emp.gender}</TableCell>
                <TableCell>{emp.dob}</TableCell>
                <TableCell>{emp.state}</TableCell>
                <TableCell>
  <Chip
    label={emp.status}
    size="small"
    color={emp.status === "Active" ? "success" : "error"}
    variant="filled"
    sx={{ fontWeight: 600 }}
  />
</TableCell>

                <TableCell>
                  <IconButton onClick={() => { setEditData(emp); setOpenForm(true); }}>
                    <Edit />
                  </IconButton>
                  <IconButton color="error" onClick={() => { setSelectedEmp(emp); setDeleteOpen(true); }}>
                    <Delete />
                  </IconButton>
                  <IconButton onClick={() => handlePrint(emp)}>
                    <Print />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>

      {/* FORM MODAL */}
      <EmployeeForm
        open={openForm}
        editData={editData}
        onSave={handleSave}
        onClose={() => {
          setOpenForm(false);
          setEditData(null);
        }}
      />

      {/* DELETE CONFIRM */}
      <Dialog open={deleteOpen} onClose={() => setDeleteOpen(false)}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          Are you sure you want to delete <b>{selectedEmp?.name}</b>?
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteOpen(false)}>Cancel</Button>
          <Button color="error" onClick={handleDeleteConfirm}>Delete</Button>
        </DialogActions>
      </Dialog>
    </DashboardLayout>
  );
};

export default Dashboard;
