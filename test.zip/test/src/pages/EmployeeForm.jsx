import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  MenuItem,
  Avatar,
  Box,
  Divider,
  IconButton
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { useForm, Controller } from "react-hook-form";

const states = ["Delhi", "Karnataka", "Telangana", "Tamil Nadu"];
const statusOptions = ["Active", "Inactive"];

const EmployeeForm = ({ open, onSave, onClose, editData }) => {
  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors }
  } = useForm({
    defaultValues: {
      name: "",
      gender: "",
      dob: "",
      state: "",
      status: "",
      image: ""
    }
  });

  const [preview, setPreview] = useState("");

  /* EDIT MODE POPULATE */
  useEffect(() => {
    if (editData) {
      reset({
        name: editData.name || "",
        gender: editData.gender || "",
        dob: editData.dob || "",
        state: editData.state || "",
        status: editData.status || ""
      });
      setPreview(editData.image || "");
    }
  }, [editData, reset]);

  /* IMAGE INPUT */
  const handleImage = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
    }
  };

  /* SUBMIT */
  const onSubmit = (data) => {
    onSave({ ...data, image: preview });
    reset();
    setPreview("");
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>
        {editData ? "Edit Employee" : "Add Employee"}
        <IconButton
          onClick={onClose}
          sx={{ position: "absolute", right: 8, top: 8 }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <Divider />

      <DialogContent sx={{ py: 2 }}>
        <Box component="form" onSubmit={handleSubmit(onSubmit)}>
          {/* IMAGE */}
          <Box textAlign="center" mb={2}>
            {preview && (
              <Avatar
                src={preview}
                sx={{ width: 80, height: 80, mx: "auto", mb: 1 }}
              />
            )}

            <TextField
              type="file"
              size="small"
              fullWidth
              inputProps={{ accept: "image/*" }}
              onChange={handleImage}
            />
          </Box>

          <Box display="flex" flexDirection="column" gap={1.5}>
            {/* NAME */}
            <TextField
              label="Full Name"
              size="small"
              {...register("name", { required: "Name is required" })}
              error={!!errors.name}
              helperText={errors.name?.message}
            />

            {/* GENDER */}
            <Controller
              name="gender"
              control={control}
              rules={{ required: "Gender is required" }}
              render={({ field }) => (
                <TextField
                  select
                  label="Gender"
                  size="small"
                  {...field}
                  error={!!errors.gender}
                  helperText={errors.gender?.message}
                >
                  <MenuItem value="Male">Male</MenuItem>
                  <MenuItem value="Female">Female</MenuItem>
                </TextField>
              )}
            />

            {/* DOB */}
            <TextField
              type="date"
              label="Date of Birth"
              size="small"
              InputLabelProps={{ shrink: true }}
              {...register("dob", { required: "DOB is required" })}
              error={!!errors.dob}
              helperText={errors.dob?.message}
            />

            {/* STATE */}
            <Controller
              name="state"
              control={control}
              rules={{ required: "State is required" }}
              render={({ field }) => (
                <TextField
                  select
                  label="State"
                  size="small"
                  {...field}
                  error={!!errors.state}
                  helperText={errors.state?.message}
                >
                  {states.map((s) => (
                    <MenuItem key={s} value={s}>
                      {s}
                    </MenuItem>
                  ))}
                </TextField>
              )}
            />

            {/* STATUS */}
            <Controller
              name="status"
              control={control}
              rules={{ required: "Status is required" }}
              render={({ field }) => (
                <TextField
                  select
                  label="Status"
                  size="small"
                  {...field}
                  error={!!errors.status}
                  helperText={errors.status?.message}
                >
                  {statusOptions.map((s) => (
                    <MenuItem key={s} value={s}>
                      {s}
                    </MenuItem>
                  ))}
                </TextField>
              )}
            />
          </Box>

          <Divider sx={{ my: 2 }} />

          <DialogActions sx={{ px: 0 }}>
            <Button size="small" onClick={onClose}>
              Cancel
            </Button>
            <Button size="small" type="submit" variant="contained">
              Save
            </Button>
          </DialogActions>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default EmployeeForm;
