import React from "react";
import {
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  useTheme,
  useMediaQuery
} from "@mui/material";
import { Dashboard } from "@mui/icons-material";
import "./Sidebar.css";

const drawerWidth = 240;

const Sidebar = ({ isOpen, isMobile, activePage, onPageChange }) => {
  const theme = useTheme();
  const isTablet = useMediaQuery(theme.breakpoints.between("sm", "md"));

  const menuItems = [
    { id: "dashboard", text: "Dashboard", icon: <Dashboard /> }
  ];

  return (
    <Drawer
      variant={isMobile ? "temporary" : "permanent"}
      open={isOpen}
      ModalProps={{ keepMounted: true }}
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        "& .MuiDrawer-paper": {
          width: drawerWidth,
          boxSizing: "border-box",
          backgroundColor: "#1976d2",
          color: "#fff"
        }
      }}
    >
      <List sx={{ mt: 8 }}>
        {menuItems.map((item) => (
          <ListItem
            button
            key={item.id}
            selected={activePage === item.id}
            onClick={() => onPageChange(item.id)}
            sx={{
              "&.Mui-selected": {
                backgroundColor: "#1976d2"
              },
              "&:hover": {
                backgroundColor: "#1976d2"
              }
            }}
          >
            <ListItemIcon sx={{ color: "#fff" }}>
              {item.icon}
            </ListItemIcon>
            <ListItemText
              primary={item.text}
              primaryTypographyProps={{
                fontSize: isTablet ? "0.9rem" : "1rem"
              }}
            />
          </ListItem>
        ))}
      </List>
    </Drawer>
  );
};

export default Sidebar;
